<?php

// Create connection
$db = mysqli_connect("localhost", "root", "", "rpl");
?>
